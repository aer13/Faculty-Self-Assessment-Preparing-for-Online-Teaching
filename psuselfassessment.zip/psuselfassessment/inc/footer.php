<br /> <br /> <br /> <br />

<footer class="footer">
   <div class="container">
      <div class="row"><hr></div>
         <div class="row">     
            <div class="col-sm-4  ">
               <small>
               <?php echo $ia['footer']['content']; ?>
               </small>
               <br /><br />
               <div class="small center-to-left ">&nbsp;</div>
            </div>
            <div class="col-sm-4">
               <div class="text-center">
                  <a target="_blank" rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-nd/4.0/88x31.png" /></a>
               </div>
            </div>

            <div class="col-sm-4">
               <div class="text-center">
            </div>
         </div>
         <div class="col-sm-4 ">
<small>
            <span class="center-to-right pull-right text-right">
               <span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">This teaching assessment</span> by <span xmlns:cc="http://creativecommons.org/ns#" property="cc:attributionName">Penn State University</span> is licensed under a <a target="_blank" rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/">Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License</a>.
            </span>
</small>
         </div>
      </div>
   </div>
</footer>

