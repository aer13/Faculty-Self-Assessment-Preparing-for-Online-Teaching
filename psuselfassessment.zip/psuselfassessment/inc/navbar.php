<div class="navbar-top">
         <h3 align=center>
            <?php include ('psuimg.php'); ?>
            <p class="text-center">
               <strong><?php echo $ia['top']['title']; ?></strong>
            </p>
         </h3>
         <br />
</div>

