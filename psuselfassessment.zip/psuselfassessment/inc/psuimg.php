            <img src="img/psu.jpg" alt="<?php echo $ia['top']['imgalt']; ?>"
                 width=175 longdesc="<?php echo $ia['top']['longdesc']; ?>">
