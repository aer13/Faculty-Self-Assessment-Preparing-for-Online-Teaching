         <!-- start WARNING box -->
         <div class="panel panel-danger">
            <div class="panel-heading">
                <h4 class="text-center"><strong><span
                   class="label label-danger">
                   <?php echo $ia['qheader']['title']; ?>
                </span></strong></h4>
                <span class="lead text-center">
                   <p align=center>
                   <?php echo $ia['qheader']['body']; ?>
                </span>
             </div>
          </div>
          <!-- end WARNING box -->
